package collection1;

import java.util.ArrayList;
import java.util.Collections;
import java.util.HashSet;
import java.util.Iterator;
import java.util.List;
import java.util.Set;

public class Main {

	public static void main(String[] args) {
		
		List<Entity> list1 = new ArrayList<Entity>();
		
//		Set<Entity> list1 = new HashSet<Entity>();
		
		list1.add(new Entity("E1",12));
		list1.add(new Entity("E2",22));
		list1.add(new Entity("E2",22));
		list1.add(new Entity("E3",25));
		list1.add(new Entity("E0",25));
		
		
//		System.out.println(list1);
//		System.out.println(list1.size());
		
//		
//		for(int i=0;i<list1.size();i++) {
//			System.out.println(list1.get(i));
//		}
		
//		for(Entity ent:list1) {
//			System.out.println(ent);
//		}

//		Iterator<Entity> iterator = list1.iterator();
//		
//		while(iterator.hasNext()) {
//			Entity ent = iterator.next();
//			System.out.println(ent);
//		}
		
		
		Collections.sort(list1, new EntityComparator());
		

//		for(Entity ent:list1) {
//			System.out.println(ent);
//		}
		
		for(int i=0;i<list1.size();i++) {
			System.out.println(list1.get(i));
		}

	}

}
