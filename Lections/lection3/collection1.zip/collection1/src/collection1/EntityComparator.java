package collection1;

import java.util.Comparator;

public class EntityComparator implements Comparator<Entity> {

	@Override
	public int compare(Entity o1, Entity o2) {
		// TODO Auto-generated method stub	
		
		return o1.getName().compareTo(o2.getName());
	}

}
